#!/bin/sh

#  stop-spark.sh
#  installer
#
#  Created by Sung Taek Kim on 7/12/15.
#  Copyright (c) 2015 PocketCluster. All rights reserved.

$SPARK_HOME/sbin/stop-all.sh
$HADOOP_HOME/sbin/mr-jobhistory-daemon.sh stop historyserver
$HADOOP_HOME/sbin/stop-yarn.sh
$HADOOP_HOME/sbin/stop-dfs.sh
