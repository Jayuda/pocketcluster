#!/usr/bin/env bash

#  start-spark.sh
#  installer
#
#  Created by Sung Taek Kim on 7/12/15.
#  Copyright (c) 2015 PocketCluster. All rights reserved.

$HADOOP_HOME/sbin/start-dfs.sh
$HADOOP_HOME/sbin/start-yarn.sh
$HADOOP_HOME/sbin/mr-jobhistory-daemon.sh start historyserver
$SPARK_HOME/sbin/start-all.sh
