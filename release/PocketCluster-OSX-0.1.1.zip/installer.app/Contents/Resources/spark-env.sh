#!/usr/bin/env bash

export JAVA_HOME=${JAVA_HOME}
export HADOOP_CONF_DIR=$HOME/bigdata/conf/hadoop
export SPARK_DRIVER_MEMORY=_MEM_
export SPARK_WORKER_MEMORY=_MEM_
export SPARK_MASTER_OPTS="$SPARK_MASTER_OPTS -Djava.awt.headless=true"
export SPARK_WORKER_OPTS="$SPARK_WORKER_OPTS -Djava.awt.headless=true"