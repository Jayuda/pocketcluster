#!/usr/bin/env bash

JHOME="$(/usr/libexec/java_home -v 1.8)"
MAX_CPU="$(sysctl -n hw.ncpu)"
MEMORY="1g"
SCALA_PATH="$(type -p scala)"
SCALA_HOME=""
SCALA_VERSION=""
INSTALL_SCALA=true
BASEDIR=$1

if [[ -n $JHOME ]]; then
  echo "************ SPARK/HADOOP INSTALL ************"
else
  echo "!!!!!!!!!!!! CANNOT INSTALL SPARK/HADOOP WITHOUT JAVA !!!!!!!!!!!!!!"
  exit 44
fi

if [[ -n $SCALA_PATH ]] && [[ -x $SCALA_PATH ]]; then

  SCALA_VERSION=$("$SCALA_PATH" -version  2>&1)

  if [[ $SCALA_VERSION == *"2.11"* ]];then
    SCALA_HOME=${SCALA_PATH/scala/}
    INSTALL_SCALA=false
    echo "Scala found!!!"
  fi

else

  INSTALL_SCALA=true

fi


echo "Create /opt directory..."
osascript -e 'do shell script "mkdir -p /opt && chown $USER:staff /opt" with administrator privileges'

# Scala
if [ $INSTALL_SCALA == true ]
then
    echo "Download & Unpack Scala"
    curl -L "http://www.scala-lang.org/files/archive/scala-2.11.6.tgz" | tar xvz - -C /opt 2>&1
    chown -R $USER:staff /opt/scala-2.11.6
    ln -s /opt/scala-2.11.6 /opt/scala
fi

# Hadoop
echo "Download & Unpack Hadoop"
curl -L "https://archive.apache.org/dist/hadoop/core/hadoop-2.4.0/hadoop-2.4.0.tar.gz" | tar xvz - -C /opt 2>&1
chown -R $USER:staff /opt/hadoop-2.4.0
ln -s /opt/hadoop-2.4.0 /opt/hadoop

# Spark
echo "Download & Unpack Spark"
curl -L "http://www.us.apache.org/dist/spark/spark-1.4.1/spark-1.4.1-bin-hadoop2.4.tgz" | tar xvz - -C /opt 2>&1
chown -R $USER:staff /opt/spark-1.4.1-bin-hadoop2.4
ln -s /opt/spark-1.4.1-bin-hadoop2.4 /opt/spark

mkdir -p /opt/hadoop/logs
chmod 777 /opt/hadoop/logs
mkdir -p /opt/spark/logs
chmod 777 /opt/spark/logs
mkdir -p /opt/spark/work
chmod 777 /opt/spark/work
mkdir -p /opt/spark/bin/metastore_db
chmod 777 /opt/spark/bin/metastore_db


echo "Setting up Environment"

#cd $HOME

echo "##### PocketCluster Added #####" >> $HOME/.bash_profile
echo "export HADOOP_HOME=/opt/hadoop" >> $HOME/.bash_profile
echo "export HADOOP_INSTALL=\$HADOOP_HOME" >> $HOME/.bash_profile
echo "export HADOOP_COMMON_HOME=\$HADOOP_HOME" >> $HOME/.bash_profile
echo "export HADOOP_MAPRED_HOME=\$HADOOP_HOME" >> $HOME/.bash_profile
echo "export HADOOP_COMMON_LIB_NATIVE_DIR=\$HADOOP_HOME/lib/native" >> $HOME/.bash_profile
echo "export HADOOP_CONF_DIR=\$HOME/bigdata/conf/hadoop" >> $HOME/.bash_profile
echo "export HADOOP_HDFS_HOME=\$HADOOP_HOME" >> $HOME/.bash_profile
echo "export YARN_HOME=\$HADOOP_HOME" >> $HOME/.bash_profile
echo "export YARN_CONF_DIR=\$HADOOP_CONF_DIR" >> $HOME/.bash_profile
echo "export SPARK_HOME=/opt/spark" >> $HOME/.bash_profile
echo "export SPARK_CONF_DIR=\$HOME/bigdata/conf/spark" >> $HOME/.bash_profile
echo "export HADOOP_OPTS=\"-Djava.library.path=\$HADOOP_HOME/lib\"" >> $HOME/.bash_profile

if [ $INSTALL_SCALA == true ]
then
  echo "export PATH=\$PATH:\$HADOOP_HOME/bin:\$HADOOP_HOME/sbin:\$SPARK_HOME/bin:\$HOME/bigdata/bin:\$SCALA_HOME/bin" >> $HOME/.bash_profile
else
  echo "export PATH=\$PATH:\$HADOOP_HOME/bin:\$HADOOP_HOME/sbin:\$SPARK_HOME/bin:\$HOME/bigdata/bin" >> $HOME/.bash_profile
fi


export HADOOP_HOME=/opt/hadoop
export HADOOP_INSTALL=$HADOOP_HOME
export HADOOP_COMMON_HOME=$HADOOP_HOME
export HADOOP_MAPRED_HOME=$HADOOP_HOME
export HADOOP_COMMON_LIB_NATIVE_DIR=$HADOOP_HOME/lib/native
export HADOOP_CONF_DIR=$HOME/bigdata/conf/hadoop
export HADOOP_HDFS_HOME=$HADOOP_HOME

export YARN_HOME=$HADOOP_HOME
export YARN_CONF_DIR=$HADOOP_CONF_DIR

export SPARK_HOME=/opt/spark
export SPARK_CONF_DIR=$HOME/bigdata/conf/spark

export HADOOP_OPTS="-Djava.library.path=$HADOOP_HOME/lib"
export PATH=$PATH:$HADOOP_HOME/bin:$HADOOP_HOME/sbin:$SPARK_HOME/bin

if [ $INSTALL_SCALA == true ]
then
  export PATH=$PATH:$SCALA_HOME/bin
fi


## create directories

mkdir -p $HOME/bigdata/hdfs/namenode
mkdir -p $HOME/bigdata/hdfs/datanode
mkdir -p $HOME/bigdata/conf/hadoop
mkdir -p $HOME/bigdata/conf/spark
mkdir -p $HOME/bigdata/bin

## setup configuration

cp /opt/hadoop/etc/hadoop/* $HOME/bigdata/conf/hadoop/
cp /opt/spark/conf/* $HOME/bigdata/conf/spark/

cp -rf $BASEDIR/core-site.xml $HOME/bigdata/conf/hadoop/
cp -rf $BASEDIR/hdfs-site.xml $HOME/bigdata/conf/hadoop/
cp -rf $BASEDIR/hadoop-env.sh $HOME/bigdata/conf/hadoop/
cp -rf $BASEDIR/mapred-site.xml $HOME/bigdata/conf/hadoop/
cp -rf $BASEDIR/yarn-site.xml $HOME/bigdata/conf/hadoop/

cp -rf $BASEDIR/spark-defaults.conf $HOME/bigdata/conf/spark/
cp -rf $BASEDIR/spark-env.sh $HOME/bigdata/conf/spark/

sed -i '' 's|${JAVA_HOME}|'${JHOME}'|g' $HOME/bigdata/conf/hadoop/hadoop-env.sh
sed -i '' 's|${JAVA_HOME}|'${JHOME}'|g' $HOME/bigdata/conf/spark/spark-env.sh
sed -i '' 's|_HOME_|'${HOME}'|g' $HOME/bigdata/conf/hadoop/hdfs-site.xml

sed -i '' 's|_MAX_CPU_|'${MAX_CPU}'|g' $HOME/bigdata/conf/spark/spark-defaults.conf
sed -i '' 's|_MEM_|'${MEMORY}'|g' $HOME/bigdata/conf/spark/spark-defaults.conf
sed -i '' 's|_MEM_|'${MEMORY}'|g' $HOME/bigdata/conf/spark/spark-env.sh


cp -rf $BASEDIR/start-service.sh $HOME/bigdata/bin/
cp -rf $BASEDIR/stop-service.sh $HOME/bigdata/bin/

chmod u+x $HOME/bigdata/bin/*

# setup ssh login

if [ ! -d "$HOME/.ssh" ]; then
    mkdir -p $HOME/.ssh
fi

#cd $HOME/.ssh

if [[ ! -f "$HOME/.ssh/id_rsa" ]] && [[ ! -f "$HOME/.ssh/id_rsa.pub" ]];then
    cat /dev/zero | ssh-keygen -t rsa -P ""
fi

PK=$(<"$HOME/.ssh/id_rsa.pub")

if grep -Fxq "$PK" $HOME/.ssh/authorized_keys
then
    echo "Public key authorized already"
else
    cat $HOME/.ssh/id_rsa.pub >> $HOME/.ssh/authorized_keys
fi

LOC="$(ssh-keyscan -t rsa localhost)"

if grep -Fxq "$LOC" $HOME/.ssh/known_hosts
then
    echo "localhost key known already"
else
    ssh-keyscan -t rsa localhost  >> $HOME/.ssh/known_hosts
fi

chmod 700 $HOME/.ssh
chmod 600 $HOME/.ssh/*

# format namenode

echo "Formating namenode"
$HADOOP_HOME/bin/hadoop namenode -format
$HADOOP_HOME/sbin/start-dfs.sh
$HADOOP_HOME/bin/hdfs dfs -mkdir -p /user/$USER
$HADOOP_HOME/sbin/stop-dfs.sh

exit 0
